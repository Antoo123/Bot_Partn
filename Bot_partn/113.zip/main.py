import telebot
from telebot import *
token='5787182783:AAFd-6QHoBcjiia5oWokUSPoSPfeYf0yHBo'
bot=telebot.TeleBot(token)
button1=types.KeyboardButton('Получить ссылку')


@bot.message_handler(commands=["start"])
def start_command_handler(message):
	bot.send_message(message.chat.id,text='Здравствуйте, подпишитесь на наш канал:')
	but_start=types.ReplyKeyboardMarkup()
	but_start.add(button1)
	bot.send_message(message.chat.id,text='https://t.me/+iCtctspUgVEyY2U5',reply_markup=but_start)

	user_id = message.from_user.id
  
	if " " in message.text:
		referrer_candidate = message.text.split()[1]
		print(referrer_candidate)

		f=open('txt.txt')
		a=f.read()
		if str(referrer_candidate) in a:
						
			file=open('txt.txt', 'r')
			a=file.read()
			b=a
			b=b.split()
			

			for i in range(len(b)):
				# print(b[i])
				if b[i]==str(referrer_candidate):
					int1=int(b[i+1])
					int1+=1
					b[i+1]=int1
					print(b)
			c=open('txt.txt','w')		
			for i in range(len(b)):
				print(b[i])
				c.write(str(b[i])+' ')
				
			
		else:
			f=open('txt.txt','a')
			f.write(str(referrer_candidate+' '+'1'+'\n'))
			
			
			
# Кнопка подписался
@bot.message_handler(content_types=['text'])
def mes1(message):
	if message.text=='Получить ссылку':
		bot.send_message(message.chat.id,text='Ваша реферальная ссылка: https://t.me/asgfwsgsbot?start='+message.from_user.username)
		but_start=types.ReplyKeyboardMarkup()
		
bot.polling(none_stop=True, interval=0)